from django.conf.urls import url
from django.shortcuts import render, redirect,HttpResponse, get_object_or_404
from django.contrib.auth.models import User, auth
from django.contrib import messages
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
import random
from django.views.decorators.csrf import csrf_exempt
from django.core.files.storage import FileSystemStorage
from django.contrib.sessions.models import Session
from datetime import date
from .models import *
import datetime



def index(request):
    banner = Banner.objects.last()

    context = {
        'banner' : banner
    }
    return render(request,'index.html',context)




def about(request):
    our_team = OurTeam.objects.all()[:4:-1]
    context = {
        'our_team' : our_team
    }
    return render(request,'about.html',context)




@login_required(login_url='login')
def cart(request):
    user = request.user

    cart = Cart.objects.filter(customer = user)
    total_price = 0
    for i in cart:
        total_price = total_price + i.item.itemdetail.in_offer_price
    context = {
        'cart' : cart,
        'total_price' : total_price
    }
    return render(request,'cart.html',context)




@login_required(login_url='login')
def checkout(request):
    return render(request,'checkout.html')





def contact(request):
    return render(request,'contact.html')




@login_required(login_url='login')
def profile(request):
    user = request.user
    try:
        total_ref_income = 0


        # refered_by_name = user.customerprofile.refered_by
        # refered_by = User.objects.filter(username = refered_by_name)[:1]
        # for i in refered_by:
        #     referid = i.id
        # referuser = User.objects.get(id = referid)
        # print(referuser)
                
        #pro = get_object_or_404(CustomerProfile, customer=referuser)  
        
        ref = ReferalIncome.objects.filter(refered_by = user.customerprofile)
        for i in ref:
            total_ref_income = total_ref_income + i.referal_income

    except:
        total_ref_income = 0
    

    context = {
        'total_ref_income' : total_ref_income
    }

    return render(request,'my-profile.html',context)




@login_required(login_url='login')
def save_profile(request):
    user = request.user
    if request.method == "POST":
        pro = get_object_or_404(CustomerProfile, customer=user)  
        pro.first_name = request.POST["fname"]
        pro.last_name = request.POST["lname"]
        pro.phone = request.POST["phone"]
        pro.country = request.POST["country"]
        pro.city = request.POST["city"]
        pro.zip_code = request.POST["zipcode"]
        pro.state = request.POST["state"]
        pro.address = request.POST["address"]
        try:    
            refer_by = request.POST["refered_by"]

            if refer_by == "None":
                pass
            else:
                pro.refered_by = refer_by
        except:
            pass

        
        print("before save")
        CustomerProfile.save(self=pro)
        print("after save save")
        messages.info(request,"Profile Updated successfully")
        return redirect("profile")

        



@login_required(login_url='login')
def cart_delete(request,myid):
    user = request.user
    cart = Cart.objects.get(id = myid)
    cart.delete()
    messages.info(request,"Your Item is removed from cart")
    return redirect("cart")






@login_required(login_url='login')
def orderlist(request):
    user = request.user
    order = OrdersList.objects.filter(order_by = user)
    context = {
        'order' : order
    }
    return render(request,'orderlist.html',context)



def shop(request):
    catagory = Catagory.objects.all()
    item = Item.objects.all()

    context = {
        'cat' : catagory,
        'item' : item
    }
    return render(request,'shop.html',context)



def single(request,myid):
    item = Item.objects.get(id = myid)
    context = {
        'item' : item
    }
    return render(request,'single.html',context)



@login_required(login_url='login')
def wishlist(request):
    return render(request,'wishlist.html')





@login_required(login_url='login')
def add_to_cart(request,myid):
    user = request.user
    item = Item.objects.get(id = myid)
    cart = Cart(customer = user,item = item)
    cart.save()
    messages.info(request,"Item successfully added in cart")

    return redirect('cart')




@login_required(login_url="login")
def AddReferalIncome(request):
    user = request.user
    add_to_1 = user.customerprofile.refered_by
    add_to = User.objects.first()
    inc = ReferalIncome(user = user,refered_by = add_to.customerprofile)
    add_to.customerprofile.total_refereal_income = add_to.customerprofile.total_refereal_income + 100
    add_to.save()




def search_item(request):
    if request.method == "POST":
        text = request.POST['search_text']
        item = Item.objects.filter(name__icontains = text)
        catagory = Catagory.objects.all()


        context = {
            'item' : item,
            'catagory' : catagory
        }
        return render(request,"search_found.html",context)





def filter_item(request,myid):

    cat = Catagory.objects.get(id = myid)
    catagory = Catagory.objects.all()
    item = Item.objects.filter(select_catagory = cat)

    context = {
        'catagory' : catagory,
        'item' : item,
        'cat' : cat
    }
    return render(request,"filter_item.html",context)






def order_now(request):
    if request.method=="POST":
        user = request.user
        cart = Cart.objects.filter(customer = user)
        for i in cart:
            ite = i.item.id
            item = Item.objects.get(id = ite)
            order = OrdersList(order_by = user,item = item,total_price = i.item.itemdetail.in_offer_price )
            order.save()
            i.delete()
        # total_price = request.POST["total_price"]


        

        ordr = OrdersList.objects.filter(order_by = user)
        total = 0
        for i in ordr:
            total = total + i.total_price
        if total>1000:
            print("INCOME GREATER THAN 1000")
            try:
                refered_by_name = user.customerprofile.refered_by
                refered_by = User.objects.filter(username = refered_by_name)[:1]
                for i in refered_by:
                    referid = i.id
                referuser = User.objects.get(id = referid)
                print(referuser)
                
                pro = get_object_or_404(CustomerProfile, customer=referuser)  



                referal_income = ReferalIncome(user = user,refered_by = pro,referal_income=100)
                referal_income.save()
                print("Refered By got income")
            except:
                print("already refered by taken income")
        else:
            print("NOT GREATER THAN 1000")
        

        return HttpResponse("Ordder placed successfully")

##########################################################################################################################################
                                                   ## LOGIN REGISTER ##
##########################################################################################################################################

def Login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = auth.authenticate(username = username, password = password)
        if user is not None:
            auth.login(request,user)
            return redirect("index")
        else:
            messages.info(request,"Invalid credentials")
            return redirect('login')
    
    else:
        return render(request, 'login.html')



def Logout(request):
    auth.logout(request)
    return redirect('login')







def createProfile(request):
    user = request.user
    cust = CustomerProfile(customer = user)
    cust.save()


def Register(request):
    if request.method =="POST":
        username=request.POST['username']
        email=request.POST['email']
        password=request.POST['password1']
        password1=request.POST['password2']
        
        if password == password1:
            if User.objects.filter(email=email):
                messages.info(request,"email already exist")
                print("email already exist")
                return render(request,"register.html")
            else:
                var=User.objects.create_user(username=username,email=email,password=password)
                print("user created")
                var.save()
                if var is not None:
                    auth.login(request,var)
                   
                    createProfile(request)
                   
                    return redirect("index")
                else:
                    messages.info(request,"register successfull login now")
                    return render(request,"login.html")
        else:
            messages.info(request,"password not matched")
            return render(request,"register.html")
    else:
        return render(request,"register.html")
    


##########################################################################################################################################
##########################################################################################################################################

