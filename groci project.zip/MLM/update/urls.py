
from django.contrib import admin
from django.urls import path
from .import views

urlpatterns = [
    path('login',views.Login,name='login'),
    path('register',views.Register,name='register'),
    path('logout',views.Logout,name='logout'),

    path('',views.index,name='index'),
    path('about',views.about,name='about'),
    path('cart',views.cart,name='cart'),
    path('checkout',views.checkout,name='checkout'),
    path('contact',views.contact,name='contact'),
    path('profile',views.profile,name='profile'),
    path('orderlist',views.orderlist,name='orderlist'),
    path('shop',views.shop,name='shop'), 
    path('single/<int:myid>/',views.single,name='single'),
    path('wishlist',views.wishlist,name='wishlist'),

    path('add_to_cart/<int:myid>/',views.add_to_cart,name='add_to_cart'),

    path('filter_item/<int:myid>/',views.filter_item,name='filter_item'),

    path('save_profile',views.save_profile,name='save_profile'),

    path('cart_delete/<int:myid>/',views.cart_delete,name='cart_delete'),

    path('order_now',views.order_now,name='order_now'),

    path('search_item',views.search_item,name='search_item'),
    


]
