from django.contrib import admin
from .models import *
# Register your models here.




admin.site.register(Banner)
admin.site.register(OurTeam)
admin.site.register(Catagory)
admin.site.register(Item)
admin.site.register(ItemDetail)
admin.site.register(Cart)

admin.site.register(CustomerProfile)

admin.site.register(OrdersList)

admin.site.register(ReferalIncome)