from django.contrib.auth.models import User
from django.db import models
from django.db.models.base import ModelState
from django.db.models.fields import CharField
from django.db.models.fields.related import ForeignKey




class Banner(models.Model):
    banner_image = models.FileField(upload_to="Banner_Image")
    off_percentage = models.CharField(max_length=3)



class OurTeam(models.Model):
    name = models.CharField(max_length=50)
    photo = models.FileField(upload_to="Our_Team")



class Catagory(models.Model):
    catagory_name = models.CharField(max_length=50)

    def __str__(self):
        return self.catagory_name


class Item(models.Model):
    select_catagory = models.ForeignKey(to=Catagory,on_delete=models.CASCADE)
    image = models.FileField(upload_to="ItemImage")
    name = models.CharField(max_length=200)

    def __str__(self):
        return self.name
    




class ItemDetail(models.Model):
    select_item = models.OneToOneField(to=Item,on_delete=models.CASCADE)
    weight = models.CharField(max_length=30)
    normal_price = models.IntegerField()
    is_offer = models.BooleanField(default=False)
    offer_percent = models.CharField(max_length=3,blank=True,null=True)
    in_offer_price = models.IntegerField()
    available_stocks = models.IntegerField()
    description = models.TextField()




class Cart(models.Model):
    customer  = models.ForeignKey(to=User,on_delete=models.CASCADE)
    item = models.ForeignKey(to=Item,on_delete=models.CASCADE)
    date = models.DateField(auto_now_add=True)






class CustomerProfile(models.Model):
    refered_by = models.CharField(max_length=50,blank=True,null=True)
    customer = models.OneToOneField(to=User,on_delete=models.CASCADE)
    first_name = models.CharField(max_length=50,blank=True,null=True)
    last_name = models.CharField(max_length=50,blank=True,null=True)
    phone  = models.CharField(max_length=50,blank=True,null=True)
    country = models.CharField(max_length=50,blank=True,null=True)
    city = models.CharField(max_length=50,blank=True,null=True)
    zip_code = models.CharField(max_length=50,blank=True,null=True)
    state = models.CharField(max_length=50,blank=True,null=True)
    address = models.CharField(max_length=50,blank=True,null=True)
    date = models.DateField(auto_now_add=True)
    total_refereal_income = models.IntegerField(default=0)
    

    def __str__(self):
        return self.customer.username





class ReferalIncome(models.Model):
    user = models.OneToOneField(to=User,on_delete=models.CASCADE)
    refered_by = models.ForeignKey(to=CustomerProfile,on_delete=models.CASCADE)
    referal_income = models.IntegerField(default=0)
    date = models.DateField(auto_now_add=True)


    





class OrdersList(models.Model):
    order_by = models.ForeignKey(to=User,on_delete=models.CASCADE)
    item = models.ForeignKey(to=Item,on_delete=models.CASCADE)
    total_price = models.IntegerField()
    date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.order_by.username


